LABORATORIO N°3: CALCULADORA BINARIA
Autor: Rodrigo Kobayashi

Sistema operativo usado :  Ubuntu 18.04.3 LTS
compiladores usados: - gcc Version 7.4.0
                     - bison (GNU Bison) 3.0.4

COMPILACION: 
        -Luego de descomprimir los archivos, abrir una terminal
        -navegar hasta la carpeta donde se encuentran los archivos
        -escribir: bash cmp.sh
        -el programa se iniciara de inmediato
        -se pueden ingresar string conteniendo números binarios y operaciones por la terminal
